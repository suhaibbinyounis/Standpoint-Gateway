<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Standpoint Gateway</title>
	<link rel="stylesheet" type="text/css" href="./css/style.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:ital,wght@1,500&display=swap" rel="stylesheet">
</head>
<body>
	
	<?php	
		include('./options.php');
	?>
		
	<div class="main_container">
		<div class="container content_feed">
		<?php
		include('./conn.php');
		$username=$_SESSION['user'];
		$userQuery = "Select * from user_details where Username='$username'";
		$result = mysqli_query($conn,$userQuery);
		if ($result->num_rows > 0){
		while($row = $result->fetch_assoc()) {
		echo "<div class=\"options_grid\">";
		echo "<p style=\"text-align:center\"><img src=\"./img/".$row['ProfilePic']."\" width=\"200\" height=\"200\" alt=\"Profile Picture\" style=\"border-radius:50%\"></p>";
		echo "<p style=\"text-align:center\">".$row['Name']."<br>@".$username."</p>";
		echo "<p style=\"text-align:center\">".$row['Bio']."</p>";
		echo "</div>";

    		}
		}

		echo "<div class=\"container content_feed\">";
  		echo "<button onclick=\"openC('changename')\">Change Name</button>";
  		echo "<button onclick=\"openC('changepassword')\">Change Password</button>";
  		echo "<button onclick=\"openC('editbio')\">Edit Bio</button>";
  		echo "<button onclick=\"openC('profilepicture')\">Edit Profile Picture</button>";
  		echo "<hr>";
	
	echo "<div id=\"changename\" class=\"login_signup container\">";
	echo "<p>Change Name:</p>";
		echo "<form action=\"./name_process.php\" method=\"POST\">";
			echo "<table>";
				echo "<tr><td>Name</td><td><input type=\"text\" name=\"fullname\" required></td></tr>";
				echo "<tr><td><button type=\"submit\" name=\"submit\">Change</button></td></tr>";
			echo "</table>";
		echo "</form>";
	echo "</div>";

	echo "<div id=\"changepassword\" class=\"login_signup container\" style=\"display:none\">";
	echo "<p>Change Password:</p>";
  		echo "<form action=\"./password_process.php\" method=\"POST\">";
			echo "<table>";
				echo "<tr><td>Old Password</td><td><input type=\"Password\" name=\"old_password\" required></td></tr>";
				echo "<tr><td>New Password</td><td><input type=\"Password\" name=\"new_password\" required></td></tr>";
				echo "<tr><td>Repeat New Password</td><td><input type=\"Password\" name=\"rep_new_password\" required></td></tr>";
				echo "<tr><td><button type=\"submit\" name=\"submit\">Change</button></td></tr>";
			echo "</table>";
		echo "</form>";
	echo "</div>";

	echo "<div id=\"editbio\" class=\"login_signup container\" style=\"display:none\">";
	echo "<p>Edit Bio: (Max 100 characters)</p>";
  		echo "<form action=\"./bio_process.php\" method=\"POST\">";
			echo "<table>";
				echo "<textarea placeholder=\"Your Bio\" maxlength=\"100\" name=\"bio\"></textarea>";
				echo "<tr><td><button type=\"submit\" name=\"submit\">Update</button></td></tr>";
			echo "</table>";
		echo "</form>";
	echo "</div>";

	echo "<div id=\"profilepicture\" class=\"login_signup container\" style=\"display:none\">";
	echo "<p>Profile Picture:</p>";
  		echo "<form action=\"./profile_picture_process.php\" method=\"POST\" enctype=\"multipart/form-data\">";
			echo "<table>";
				echo "<tr><td><input type=\"file\" name=\"image\"></td>";
				echo "<td><button type=\"submit\" name=\"upload\">Upload</button></td></tr>";
			echo "</table>";
		echo "</form>";
	echo "</div>";

	if(isset($_SESSION['error'])){
		echo "<p style=\"text-align:center;\"><strong>".$_SESSION['error']."</strong></p>";
		unset($_SESSION['error']);
	}
	echo "<br><p style=\"text-align:center;\">This project is still under Beta Mode. Proceed with caution.</p>";
	echo "</div>";



	echo "<script>";
		echo "function openC(clickname) {";
  			echo "var i;";
  			echo "var x = document.getElementsByClassName(\"login_signup\");";
  			echo "for (i = 0; i < x.length; i++) {";
    		echo "x[i].style.display = \"none\";";
  			echo "}";
  			echo "document.getElementById(clickname).style.display = \"block\";";
		echo "}";
	echo "</script>";
			
		?>
		</div>

		<?php
			include('./adfeed.php');
		?>
	</div>
	
	<?php include('./footer.php');?>

</body>
</html>