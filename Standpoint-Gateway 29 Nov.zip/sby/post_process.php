<?php
	session_start();

	if(isset($_POST['submit'])){
		include('./conn.php');

		$username = $_SESSION['user'];
		$post = $_POST['post'];
		date_default_timezone_set('Asia/Kolkata');
		$date = date("F j, Y, g:i a");
		$postQuery = "insert into user_post(Username,Post,PostTime) values('$username','".mysqli_real_escape_string($conn,htmlspecialchars($_POST['post']))."','$date');";
		if(mysqli_query($conn,$postQuery)){
			header('location: index.php');	
		}
	}
?>