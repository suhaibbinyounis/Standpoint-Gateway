<?php
	session_start();
	if(isset($_POST['submit'])){
		include('./conn.php');

		$username = mysqli_real_escape_string($conn,htmlspecialchars($_POST['username']));
		$fullname = mysqli_real_escape_string($conn,htmlspecialchars($_POST['fullname']));
		$email = mysqli_real_escape_string($conn,htmlspecialchars($_POST['email']));
		$password = mysqli_real_escape_string($conn,htmlspecialchars($_POST['password']));
		$rep_password = mysqli_real_escape_string($conn,htmlspecialchars($_POST['rep_password']));
		if($username==""||$fullname==""||$email==""||$password==""||$rep_password==""){
			$_SESSION['error']="Empty fields! Please fill all the fields.";
			header('location: index.php');
		}
		elseif($password!=$rep_password){
			$_SESSION['error']="Password does not match";
			header('location: index.php');
		}
		else{
			//checking username
			$usernameCheck = "Select * from user_details where Username='$username'";
			$emailCheck = "Select * from user_details where Email='$email'";
			$usernameResult = mysqli_query($conn,$usernameCheck);
			$emailResult = mysqli_query($conn,$emailCheck);
			if ($usernameResult->num_rows > 0){
				$_SESSION['error']="Username is not available";
				header('location: index.php');
			}
			elseif($emailResult->num_rows > 0){
				$_SESSION['error']="Email already in use";
				header('location: index.php');
			}
			else{
				$insertQuery = "INSERT INTO user_details(Username,Name,Email,Password) VALUES('$username','$fullname','$email','$password');";
				if(mysqli_query($conn,$insertQuery)){
					$_SESSION['user'] = $username;
                	header('location: index.php');
            	}
			}
        }

	}
?>
