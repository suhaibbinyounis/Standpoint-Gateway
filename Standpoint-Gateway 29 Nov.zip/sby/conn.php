<?php
$dbServerName = 'localhost';
$dbUserName = 'root';
$dbPassword = '';
$dbDatabase = 'StandpointGateway';
$conn = mysqli_connect($dbServerName,$dbUserName,$dbPassword,$dbDatabase);
?>