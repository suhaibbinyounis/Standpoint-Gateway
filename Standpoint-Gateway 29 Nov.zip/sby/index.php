<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Standpoint Gateway</title>
	<link rel="stylesheet" type="text/css" href="./css/style.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:ital,wght@1,500&display=swap" rel="stylesheet">
</head>
<body>
	
	<?php	
		include('./options.php');
	?>
		
	<div class="main_container">
		<?php
		if(!isset($_SESSION['user'])){
			include('login_signup.php');
		}
		else{
			include('./contentfeed.php');
		}
		?>

		<?php
			include('./adfeed.php');
		?>
	</div>
	
	<?php include('./footer.php');?>

</body>
</html>