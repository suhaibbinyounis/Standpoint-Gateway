<?php
	echo "<div class=\"container options\">";
				echo "<div class=\"options_grid\">";
					echo "<a href=\"./index.php\"><img src=\"./img/logo.png\"></a>";
				echo "</div>";
				echo "<div class=\"options_grid\">";
				echo "<a href=\"./index.php\"><button>Home</button></a>";
				if(isset($_SESSION['user'])){
				echo "<button>Explore</button>";
				echo "<button>Bookmarks</button>";
				echo "<a href=\"profile.php\"><button>Profile</button></a>";
				echo "<button>Settings</button>";
				}
				echo "</div>";
				echo "<div class=\"options_grid\">";
				echo "<p>This project is still in Beta Mode.<br>Proceed with caution.</p>";
				echo "</div>";
				echo "<div class=\"options_grid\">";
					echo "<button>Mine My Profile</button>";
					echo "<button>Mine Other Profile</button>";
					if(isset($_SESSION['user']))
					echo "<a href=\"logout.php\"><button>Log out</button><a>";
				echo "</div>";

			echo "</div>";
?>