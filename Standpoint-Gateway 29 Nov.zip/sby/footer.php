<?php
	echo "<div class=\"footer\">";
		echo "<p>All Rights Reserved | © Standpoint Gateway</p>";
		echo "<p><a href=\"http://tiny.cc/sby\">@suhaibbinyounis</a></p>";
	echo "</div>";
?>