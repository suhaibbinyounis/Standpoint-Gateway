<?php
	session_start();

	if(isset($_POST['submit'])){
		include('./conn.php');
		$username = $_SESSION['user'];
		$fullname = mysqli_real_escape_string($conn,htmlspecialchars($_POST['fullname']));

		$updateQuery = "update user_details set Name='$fullname' where Username='$username'";
		if(mysqli_query($conn,$updateQuery)){
        	header('location: profile.php');
    	}
    	else{
    		$_SESSION['error']="Couldn't change name! Try again.";
			header('location: index.php');
    	}
		
	}
?>