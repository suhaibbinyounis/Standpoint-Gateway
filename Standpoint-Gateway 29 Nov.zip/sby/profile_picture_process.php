<?php
	session_start();

	if(isset($_POST['upload'])){
		include('./conn.php');
		$username = $_SESSION['user'];
		$filename = $_FILES['image']['name']; 
    	$folder = "./img/".basename($filename);
    	$sql = "update user_details set ProfilePic='$filename' where Username='$username'";
    	if(mysqli_query($conn, $sql)){
    		if (move_uploaded_file($_FILES['image']['tmp_name'], $folder))  { 
            	header('location: profile.php'); 
        	}
        	else{ 
            	$_SESSION['error']="Error occured while uploading photo! Try again.";
				header('location: profile.php');
        	}
        }
        else{
        	$_SESSION['error']="Query Failed! Try again.";
			header('location: profile.php');
        } 		
	}
?>