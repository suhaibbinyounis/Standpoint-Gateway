<?php
	echo "<div class=\"container content_feed\">";
  		echo "<button onclick=\"openC('login')\">Log in</button>";
  		echo "<button onclick=\"openC('signup')\">Create a account</button>";
  		echo "<hr>";
	
	echo "<div id=\"login\" class=\"login_signup container\">";
	echo "<p>Login:</p>";
		echo "<form action=\"./login_process.php\" method=\"POST\">";
			echo "<table>";
				echo "<tr><td>Username</td><td><input type=\"text\" name=\"username\" required></td></tr>";
				echo "<tr><td>Password</td><td><input type=\"Password\" name=\"password\" required></td></tr>";
				echo "<tr><td><button type=\"submit\" name=\"submit\">Log in</button></td></tr>";
			echo "</table>";
		echo "</form>";
	echo "</div>";

	echo "<div id=\"signup\" class=\"login_signup container\" style=\"display:none\">";
	echo "<p>Signup:</p>";
  		echo "<form action=\"./signup_process.php\" method=\"POST\">";
			echo "<table>";
				echo "<tr><td>Username</td><td><input type=\"text\" name=\"username\" required></td></tr>";
				echo "<tr><td>Full Name</td><td><input type=\"text\" name=\"fullname\" required></td></tr>";
				echo "<tr><td>Email</td><td><input type=\"email\" name=\"email\" required></td></tr>";
				echo "<tr><td>Password</td><td><input type=\"Password\" name=\"password\" required></td></tr>";
				echo "<tr><td>Repeat Password</td><td><input type=\"Password\" name=\"rep_password\" required></td></tr>";
				echo "<tr><td><button type=\"submit\" name=\"submit\">Sign up</button></td></tr>";
			echo "</table>";
		echo "</form>";
	echo "</div>";
	if(isset($_SESSION['error'])){
		echo "<p style=\"text-align:center;\"><strong>".$_SESSION['error']."</strong></p>";
		unset($_SESSION['error']);
	}
	echo "<br><p style=\"text-align:center;\">This project is still under Beta Mode. Proceed with caution.</p>";
	echo "</div>";



	echo "<script>";
		echo "function openC(clickname) {";
  			echo "var i;";
  			echo "var x = document.getElementsByClassName(\"login_signup\");";
  			echo "for (i = 0; i < x.length; i++) {";
    		echo "x[i].style.display = \"none\";";
  			echo "}";
  			echo "document.getElementById(clickname).style.display = \"block\";";
		echo "}";
	echo "</script>";
?>