<?php
	echo "<div class=\"container ad_feed\">";
				if(isset($_SESSION['user'])){
				include('./conn.php');
		$username=$_SESSION['user'];
		$userQuery = "Select * from user_details where Username='$username'";
		$result = mysqli_query($conn,$userQuery);
		if ($result->num_rows > 0){
		while($row = $result->fetch_assoc()) {
		echo "<div class=\"options_grid\">";
		echo "<p style=\"text-align:center\"><img <img src=\"./img/".$row['ProfilePic']."\" width=\"100\" height=\"100\" alt=\"Profile Picture\" style=\"border-radius:50%\"></p>";
		echo "<p style=\"text-align:center\">".$row['Name']."<br>@".$username."</p>";
		echo "<p style=\"text-align:center\">".$row['Bio']."</p>";
		echo "</div>";

    		}
		}
			}
				echo "<div class=\"options_grid\">";
					if(isset($_SESSION['user'])){
					echo "<a href=\"topprofiles.php\"><button>Top Profiles</button></a>";
					echo "<button>Analytics</button>";
					echo "<button>Help Center</button>";
					}
					echo "<a href=\"./about.php\"><button>About</button></a>";
				echo "</div>";
				echo "<div class=\"options_grid\">";
					echo "<div class=\"ads\">";
						echo "<p>AD 1</p>";
						echo "<img src=\"./img/adexample.jpg\">";
					echo "</div>";
					echo "<div class=\"ads\">";
						echo "<p>AD 2</p>";
						echo "<img src=\"./img/adexample.jpg\">";
					echo "</div>";
				echo "</div>";
				echo "</div>";
?>