<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Standpoint Gateway</title>
	<link rel="stylesheet" type="text/css" href="./css/style.css">
</head>
<body>
	
	<?php	
		include('./options.php');
	?>
		
	<div class="main_container">
		<?php
echo "<div class=\"container content_feed\">";
echo "<div class=\"optiions_grid\">";
echo '<h1>OPINION MINING ON WEB BASED COMMUNITIES</h1>';
echo '<p>';
echo 'Reg No: RA1711003011078';
echo '</p>';
echo '<p>';
echo 'College: SRM INSTITUTE OF SCIENCE AND TECHNOLOGY';
echo '</p>';
echo '<p>';
echo 'Guide: Dr. R. Naresh';
echo '</p>';
echo '<p>';
echo 'This project is done by <strong>Suhaib Bin Younis</strong> as a major project for his B.Tech CSE.';
echo '</p>';
echo '</div>';
echo "<div class=\"options_grid\">";
echo '<h3>About this Project:</h3>';
echo '<p>Coming Soon</p>';
echo '</div>';
echo '</div>';
		?>
		<?php
			include('./adfeed.php');
		?>
	</div>
	
	<?php include('./footer.php');?>

</body>
</html>