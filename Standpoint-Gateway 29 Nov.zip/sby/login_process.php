<?php
	session_start();

	if(isset($_POST['submit'])){
		include('./conn.php');

		$username = mysqli_real_escape_string($conn,htmlspecialchars($_POST['username']));
		$password = mysqli_real_escape_string($conn,htmlspecialchars($_POST['password']));

		$loginQuery = "SELECT * from user_details where Username='$username' and Password='$password'";
		$result=mysqli_query($conn,$loginQuery);
		if(mysqli_num_rows($result)> 0){
        	$_SESSION['user'] = $username;
        	header('location: index.php');
    	}
    	else{
    		$_SESSION['error']="Invaid credentials! Try again.";
			header('location: index.php');
    	}
		
	}
?>