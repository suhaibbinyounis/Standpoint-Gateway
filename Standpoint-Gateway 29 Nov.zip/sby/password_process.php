<?php
	session_start();

	if(isset($_POST['submit'])){
		include('./conn.php');
		$username = $_SESSION['user'];
		$old_password = mysqli_real_escape_string($conn,htmlspecialchars($_POST['old_password']));
		$new_password = mysqli_real_escape_string($conn,htmlspecialchars($_POST['new_password']));
		$rep_new_password = mysqli_real_escape_string($conn,htmlspecialchars($_POST['rep_new_password']));

		$checkOldPassword = "select * from user_details where Username='$username' and Password='$old_password'";
		$passResult = mysqli_query($conn,$checkOldPassword);
		if(mysqli_num_rows($passResult)> 0){
			if($new_password==$rep_new_password){
				$updateQuery = "update user_details set Password='$new_password' where Username='$username'";
				if(mysqli_query($conn,$updateQuery)){
        			header('location: profile.php');
    			}
    			else{
    				$_SESSION['error']="Couldn't change password! Try again.";
					header('location: profile.php');
    			}
			}
			else{
    				$_SESSION['error']="Password dont match! Try again.";
					header('location: profile.php');
    			}

		}
		else{
    				$_SESSION['error']="Wrong old password! Try again.";
					header('location: profile.php');
    			}
		
		
		
	}
?>