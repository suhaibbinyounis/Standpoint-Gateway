<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Standpoint Gateway</title>
	<link rel="stylesheet" type="text/css" href="./css/style.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:ital,wght@1,500&display=swap" rel="stylesheet">
</head>
<body>
	
	<?php	
		include('./options.php');
	?>
		
	<div class="main_container">
		<div class="container content_feed">
		<?php
			include('./conn.php');
			$postFeedQuery = "Select * from user_details";
			$result = mysqli_query($conn,$postFeedQuery);
			if ($result->num_rows > 0){
				$i=1;
				while($row = $result->fetch_assoc()) {
				echo "<div class=\"options_grid\">";
				echo "<p>".$i."</p>";
				echo "<p><img src=\"./img/".$row['ProfilePic']."\" width=\"150\" height=\"150\" class=\"profilePicture\">".$row['Name']." | @".$row['Username']."</p>";
				echo "</div>";
				$i += 1;
    			}
			}
		?>
		</div>

		<?php
			include('./adfeed.php');
		?>
	</div>
	
	<?php include('./footer.php');?>

</body>
</html>