<?php
	session_start();

	if(isset($_POST['submit'])){
		include('./conn.php');
		$username = $_SESSION['user'];
		$bio = mysqli_real_escape_string($conn,htmlspecialchars($_POST['bio']));

		$updateQuery = "update user_details set Bio='$bio' where Username='$username'";
		if(mysqli_query($conn,$updateQuery)){
        	header('location: profile.php');
    	}
    	else{
    		$_SESSION['error']="Couldn't update bio! Try again.";
			header('location: index.php');
    	}
		
	}
?>