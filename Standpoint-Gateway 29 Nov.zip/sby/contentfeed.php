<?php
	echo "<div class=\"container content_feed\">";
				
				echo "<div class=\"\">";
					echo "<img src=\"./img/4.png\" height=\"100%\" width=\"100%\">";
				echo "</div>";

echo "<div class=\"container content_feed\">";
echo "<form action=\"./post_process.php\" method=\"POST\">";
echo "<p>What's on your mind?</p>";
echo "<textarea rows=12 placeholder=\"Your text here...\" name=\"post\"></textarea>";
echo "<button type=\"submit\" name=\"submit\">Post</button>";
echo "</form>";
echo "<hr>";

include('./conn.php');
$postFeedQuery = "Select * from user_post inner join user_details on user_details.Username=user_post.Username order by PostTime desc";
$result = mysqli_query($conn,$postFeedQuery);
if ($result->num_rows > 0){
	while($row = $result->fetch_assoc()) {
		echo "<div class=\"options_grid\">";
		echo "<p><img src=\"./img/".$row['ProfilePic']."\" width=\"40\" height=\"40\" class=\"profilePicture\">".$row['Username']." | ".$row['PostTime']."</p>";
		echo "<hr class=\"hrtype\">";
		echo "<pre><p>".$row['Post']."</p></pre>";
		echo "</div>";

    }
}

echo "<div class=\"options_grid\">";
echo "<p><img src=\"./img/B.jpg\" width=\"40\" height=\"40\" class=\"profilePicture\"> Random Scientist</p>";
echo "<hr class=\"hrtype\">";
echo "<p>A needlegun scaler, needle scaler or needle-gun is a tool used to remove rust, mill scale, and old paint from metal surfaces. The tool is used in metalwork applications as diverse as home repair, automotive repair and shipboard preservation.</p>";
echo '<p>';
echo '<ul>';
echo '<li>Mood: NA</li>';
echo '<li>Vibe: NA</li>';
echo '<li>Score: NA</li>';
echo '</ul>';
echo '</p>';
echo "</div>";


echo "<div class=\"options_grid\">";
echo "<hr style=\"width:100%\">";
echo "<p>• Sponsored •</p>";
echo "<p><img src=\"./img/sponsor.jpg\" ></p>";
echo "<p>Buy this that and some random stuff too. Because you have too much of money</p>";
echo "<hr style=\"width:100%\">";
echo "</div>";


echo "<div class=\"options_grid\">";
echo "<p><img src=\"./img/A.jpeg\" width=\"40\" height=\"40\" class=\"profilePicture\"> The Nerdy Guy</p>";
echo "<hr class=\"hrtype\">";
echo "<p>It’s a pandemic. You get sick, you go to a place that can handle patients while observing the guidelines to prevent transmission. Most of the private practitioners don’t have the space or the manpower to observe those guidelines, so they don’t take appointments. Simple. </p>";
echo "</div>";


echo "</div>";
	echo "</div>";
?>